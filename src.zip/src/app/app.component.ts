import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { UIChart } from 'primeng/chart';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  @ViewChild('graph') graph: UIChart
  colunas = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho', 'Agosto', 'Setembro','Outubro', 'Novembro', 'Dezembro'];
  min_value = 15;
  max_value = 50;
  escala_grafico = { stepSize: 10, min: 0, max: 200 };
  
  data: any;
  options: any;
  
  totalizador = {
    id: 'totalizador',
    beforeUpdate: chart => {
      let totais = {};
      let indice_coluna = 0;

      chart.data.datasets.forEach((dataset, datasetIndex) => {
        //SOMAR APENAS GRÁFICOS DE BARRA
        if (dataset.type == 'bar') { 
          if (chart.isDatasetVisible(datasetIndex)) {
            indice_coluna = datasetIndex;
            dataset.data.forEach((value, index) => {
              totais[index] = (totais[index] || 0) + value;
            })
          }
        }
      });
  
      chart.$totalizador = {
        totais: totais,
        indice_coluna: indice_coluna
      }
    }
  };

  ngOnInit(): void {
    this.data = {
      labels: this.colunas,
      datasets: [
        {
          type:             'line',
          label:            'Endividamento BVW',
          data:             this.getRandomArray(this.colunas.length),
          backgroundColor:  '#2D313C',
          borderColor:      '#2D313C',
          fill:             false
        },
        {
          type:             'line',
          label:            'Vencidos BVW',
          data:             this.getRandomArray(this.colunas.length),
          backgroundColor:  '#FFD100',
          borderColor:      '#FFD100',
          fill:             false
        },
        {
          type:             'bar',
          label:            'Prejuízo',
          data:             this.getRandomArray(this.colunas.length),
          stack:            'stack1',
          yAxisID:          'bar-y-axis',
          backgroundColor:  'rgba(165, 0, 33, 1)',
          borderColor:      'rgba(165, 0, 33, 1)'
        },
        {
          type:             'bar',
          label:            'Vencidos',
          data:             this.getRandomArray(this.colunas.length),
          stack:            'stack1',
          yAxisID:          'bar-y-axis',
          backgroundColor:  'rgba(226, 103, 0, 1)',
          borderColor:      'rgba(226, 103, 0, 1)'
        },
        {
          type:             'bar',
          label:            'À Vencer',
          data:             this.getRandomArray(this.colunas.length),
          stack:            'stack1',
          yAxisID:          'bar-y-axis',
          backgroundColor:  'rgba(33, 165, 250, 1)',
          borderColor:      'rgba(33, 165, 250, 1)'
        },
        {
          type:             'bar',
          label:            'Outros',
          data:             this.getRandomArray(this.colunas.length),
          stack:            'stack1',
          yAxisID:          'bar-y-axis',
          backgroundColor:  'rgba(191, 191, 191, 1)',
          borderColor:      'rgba(191, 191, 191, 1)'
        },
      ]
    }
    
    this.options = {
      elements: {
        line: {
          tension: 0 // deixa o gráfico de linhas sem curvatura
        }
      },
      legend: {
        position: 'bottom'
      },
      scales: {
        yAxes: [
          { 
            stacked: false,
            ticks: this.escala_grafico
          },
          {
            id: "bar-y-axis",
            stacked: true,
            display: false,
            ticks: this.escala_grafico
          }
        ]
      },
      plugins: {
        datalabels: {
          formatter: (value, ctx) => {
            const total = ctx.chart.$totalizador.totais[ctx.dataIndex]
            if (total) {
              return total.toLocaleString("pt-BR", { 
                minimumFractionDigits: 2 , 
                style: 'currency', 
                currency: 'BRL' 
              });
            }
          },
          align:  'end',
          anchor: 'end',
          display: function(ctx) {
            return ctx.datasetIndex === ctx.chart.$totalizador.indice_coluna;
          }
        }
      }
    };
  }

  getRandomInt() {
    const min = Math.ceil(this.min_value);
    const max = Math.floor(this.max_value);
    return Math.floor(Math.random() * (max - min)) + min;
  }

  getRandomArray(qtd) {
    const array = [];
    while (qtd > 0) {
      array.push(this.getRandomInt());
      qtd--;
    }
    return array;
  }

  getBase64Img() {
    var base64 = this.graph.getBase64Image()
    return base64
  }

  exportarPDF() {
    const documento = { 
      content: [
        'Exemplo exportação para PDF',
        {
          image: this.getBase64Img(),
          width:  500,
			    height: 300,
        }
      ]
    };
    
    const pdf = pdfMake.createPdf(documento);
    pdf.download();
  }
}
